import { useState, useEffect, useCallback } from "react";

/* አማላጅ ፕላስ - single-page marketplace + escrow hub.
   Set API to your FastAPI origin. The token lives in memory only (refresh = sign in again);
   in your own deployment you may move it to an httpOnly cookie or localStorage. */
const API = "http://localhost:8000";
const PLATFORMS = ["TikTok", "YouTube", "Telegram", "Instagram", "Facebook", "X_Twitter", "Website_SaaS"];
const PLABEL = { TikTok: "TikTok", YouTube: "YouTube", Telegram: "Telegram", Instagram: "Instagram", Facebook: "Facebook", X_Twitter: "X (Twitter)", Website_SaaS: "Websites / SaaS" };

const T = {
  en: {
    market: "Marketplace", sell: "Sell an account", deals: "My deals", archive: "Sold archive", admin: "Admin",
    login: "Sign in", register: "Create account", logout: "Sign out", all: "All platforms",
    fullName: "Full name", phone: "Phone number", email: "Email (optional)", password: "Password", tgId: "Telegram ID (optional)",
    followers: "Followers", revenue: "Monthly revenue", price: "Asking price", engagement: "Engagement", category: "Category",
    description: "Description", title: "Account title", proof: "Analytics screenshot proof", handle: "Handle / link (private, for review)",
    quality: "Verified quality score", submit: "Submit for review", startEscrow: "Buy with escrow", agreed: "Agreed amount (ETB)",
    fee: "Amalaj Plus fee (2%)", payout: "Seller receives", cooldown: "Safety hold (days)", cancel: "Cancel", back: "Back",
    empty: "No listings match these filters yet.", noDeals: "You have no deals yet.", noArchive: "No completed deals yet.",
    "Very Good Price": "Very good price", "Fair Price": "Fair price", "High Price": "High price",
    transferred: "I handed over the login", confirmAccess: "I can log in - start safety hold", dispute: "Open dispute",
    confirmDeposit: "Confirm deposit", holdLeft: "left in safety hold", payRef: "Pay into escrow with reference",
    chat: "Deal chat", send: "Send", offPlatform: "Negotiating or paying outside Amalaj Plus is not allowed and is logged.",
    pending: "Pending review", approve: "Approve", suspend: "Suspend", release: "Release to seller", refund: "Refund buyer",
    disputes: "Disputes", review: "Listings awaiting review", reason: "Describe the problem (min. 10 characters)", note: "Resolution note",
    sellerNote: "Listings are reviewed before they go public. Telegram channels can be auto-verified with our bot.",
    signInFirst: "Sign in to continue.", saved: "Submitted. An admin will review your listing.", sold: "Sold",
  },
  am: {
    market: "ገበያ", sell: "አካውንት ይሽጡ", deals: "የእኔ ስምምነቶች", archive: "የተሸጡ ቻናሎች", admin: "አስተዳዳሪ",
    login: "ግባ", register: "ተመዝገብ", logout: "ውጣ", all: "ሁሉም ፕላትፎርሞች",
    fullName: "ሙሉ ስም", phone: "ስልክ ቁጥር", email: "ኢሜይል (አማራጭ)", password: "የይለፍ ቃል", tgId: "የቴሌግራም መታወቂያ (አማራጭ)",
    followers: "ተከታዮች", revenue: "ወርሃዊ ገቢ", price: "የሚጠየቀው ዋጋ", engagement: "ተሳትፎ", category: "ምድብ",
    description: "መግለጫ", title: "የአካውንት ርዕስ", proof: "የትንተና ማረጋገጫ ፎቶ", handle: "ስም / ሊንክ (ለግምገማ ብቻ)",
    quality: "የተረጋገጠ የጥራት ነጥብ", submit: "ለግምገማ ላክ", startEscrow: "በእስክሮው ግዛ", agreed: "የተስማማው ዋጋ (ብር)",
    fee: "የአማላጅ ፕላስ ክፍያ (2%)", payout: "ሻጭ የሚቀበለው", cooldown: "የደህንነት እገዳ (ቀናት)", cancel: "ተው", back: "ተመለስ",
    empty: "ከዚህ ማጣሪያ ጋር የሚሄድ ዝርዝር የለም።", noDeals: "እስካሁን ምንም ስምምነት የለዎትም።", noArchive: "እስካሁን የተጠናቀቀ ስምምነት የለም።",
    "Very Good Price": "በጣም ጥሩ ዋጋ", "Fair Price": "ተገቢ ዋጋ", "High Price": "ከፍተኛ ዋጋ",
    transferred: "መግቢያውን አስተላልፌያለሁ", confirmAccess: "መግባት ችያለሁ - እገዳውን ጀምር", dispute: "አለመግባባት አንሳ",
    confirmDeposit: "ክፍያ አረጋግጥ", holdLeft: "የደህንነት እገዳ ቀርቷል", payRef: "በዚህ ማመሳከሪያ ወደ እስክሮው ይክፈሉ",
    chat: "የስምምነት ውይይት", send: "ላክ", offPlatform: "ከአማላጅ ፕላስ ውጭ መደራደር ወይም መክፈል ክልክል ነው፤ ይመዘገባል።",
    pending: "ግምገማ በመጠባበቅ ላይ", approve: "አጽድቅ", suspend: "አግድ", release: "ለሻጭ ልቀቅ", refund: "ለገዢ መልስ",
    disputes: "አለመግባባቶች", review: "ግምገማ የሚጠብቁ ዝርዝሮች", reason: "ችግሩን ይግለጹ (ቢያንስ 10 ፊደል)", note: "የውሳኔ ማስታወሻ",
    sellerNote: "ዝርዝሮች ከመታተማቸው በፊት ይገመገማሉ። የቴሌግራም ቻናሎች በቦታችን በራስ-ሰር ሊረጋገጡ ይችላሉ።",
    signInFirst: "ለመቀጠል ይግቡ።", saved: "ተልኳል። አስተዳዳሪ ዝርዝርዎን ይገመግማል።", sold: "ተሽጧል",
  },
};
const STATUS = {
  en: { Pending_Deposit: "Waiting for deposit", Secured_in_Escrow: "Secured in escrow", Credentials_Transferred: "Login handed over", Buyer_Verification_Period: "Safety hold", Completed: "Completed", Disputed: "Disputed", Refunded: "Refunded" },
  am: { Pending_Deposit: "ክፍያ በመጠባበቅ ላይ", Secured_in_Escrow: "በእስክሮው ተቀምጧል", Credentials_Transferred: "መግቢያ ተላልፏል", Buyer_Verification_Period: "የደህንነት እገዳ", Completed: "ተጠናቋል", Disputed: "አለመግባባት", Refunded: "ተመላሽ ተደርጓል" },
};
const TAG_STYLE = { "Very Good Price": "bg-emerald-100 text-emerald-900", "Fair Price": "bg-amber-100 text-amber-900", "High Price": "bg-rose-100 text-rose-900" };
const etb = (n) => Number(n).toLocaleString("en-US", { maximumFractionDigits: 2 }) + " ETB";
const fmtK = (n) => (n >= 1e6 ? (n / 1e6).toFixed(1) + "M" : n >= 1e3 ? (n / 1e3).toFixed(1) + "K" : String(n));
const inputCls = "w-full border-2 border-slate-300 rounded-md px-3 py-2 text-slate-900 bg-white focus:outline-none focus:border-slate-900";
const btn = "px-4 py-2 rounded-md font-semibold border-2 border-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-400";
const btnPrimary = btn + " bg-slate-900 text-white hover:bg-slate-700";
const btnGhost = btn + " bg-white text-slate-900 hover:bg-slate-100";

export default function AmalajPlus() {
  const [lang, setLang] = useState("am");
  const [view, setView] = useState("market");
  const [token, setToken] = useState(null);
  const [me, setMe] = useState(null);
  const [showAuth, setShowAuth] = useState(false);
  const [toast, setToast] = useState(null);
  const [selected, setSelected] = useState(null);
  const t = T[lang];

  const notify = (msg, bad = false) => { setToast({ msg, bad }); setTimeout(() => setToast(null), 5000); };

  const api = useCallback(async (path, { method = "GET", json, form } = {}) => {
    const headers = {};
    if (token) headers.Authorization = `Bearer ${token}`;
    if (json) headers["Content-Type"] = "application/json";
    const res = await fetch(API + path, { method, headers, body: form || (json ? JSON.stringify(json) : undefined) });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const d = data.detail;
      throw new Error(Array.isArray(d) ? d.map((e) => e.msg).join("; ") : d || `Error ${res.status}`);
    }
    return data;
  }, [token]);

  const needLogin = () => { notify(t.signInFirst, true); setShowAuth(true); };
  const go = (v) => { setView(v); setSelected(null); };

  const nav = [["market", t.market], ["sell", t.sell], ["deals", t.deals], ["archive", t.archive], ...(me?.is_admin ? [["admin", t.admin]] : [])];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900" style={{ fontFamily: "'Noto Sans Ethiopic','Inter',system-ui,sans-serif" }}>
      <style>{"@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Ethiopic:wght@400;600;800&family=Inter:wght@400;600;800&display=swap');"}</style>

      <header className="bg-slate-900 text-white">
        <div className="max-w-6xl mx-auto px-4 py-3 flex flex-wrap items-center gap-3">
          <button onClick={() => go("market")} className="text-2xl font-extrabold tracking-tight text-amber-400">
            {lang === "am" ? "አማላጅ ፕላስ" : "Amalaj Plus"}
          </button>
          <nav className="flex flex-wrap gap-1 flex-1">
            {nav.map(([k, label]) => (
              <button key={k} onClick={() => ((k === "sell" || k === "deals" || k === "admin") && !me ? needLogin() : go(k))}
                className={"px-3 py-1.5 rounded-md text-sm font-semibold " + (view === k ? "bg-amber-400 text-slate-900" : "hover:bg-slate-700")}>
                {label}
              </button>
            ))}
          </nav>
          <button onClick={() => setLang(lang === "am" ? "en" : "am")} className="border-2 border-white rounded-md px-3 py-1 text-sm font-semibold hover:bg-slate-700" aria-label="Switch language">
            {lang === "am" ? "EN" : "አማ"}
          </button>
          {me ? (
            <button onClick={() => { setToken(null); setMe(null); go("market"); }} className="text-sm underline">{me.full_name} · {t.logout}</button>
          ) : (
            <button onClick={() => setShowAuth(true)} className="bg-amber-400 text-slate-900 rounded-md px-3 py-1.5 text-sm font-bold">{t.login}</button>
          )}
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-6">
        {view === "market" && (selected
          ? <Detail id={selected} t={t} lang={lang} api={api} me={me} onBack={() => setSelected(null)} needLogin={needLogin} notify={notify} onDeal={() => go("deals")} />
          : <Market t={t} lang={lang} api={api} onOpen={setSelected} notify={notify} />)}
        {view === "sell" && <Sell t={t} api={api} notify={notify} onDone={() => go("market")} />}
        {view === "deals" && <Deals t={t} lang={lang} api={api} me={me} notify={notify} />}
        {view === "archive" && <Archive t={t} api={api} notify={notify} />}
        {view === "admin" && <Admin t={t} lang={lang} api={api} notify={notify} />}
      </main>

      {showAuth && <Auth t={t} api={api} notify={notify} onClose={() => setShowAuth(false)}
        onAuth={(r) => { setToken(r.token); setMe(r.user); setShowAuth(false); }} />}
      {toast && (
        <div role="status" className={"fixed bottom-4 left-1/2 -translate-x-1/2 px-4 py-3 rounded-md font-semibold shadow-lg z-50 " + (toast.bad ? "bg-rose-700 text-white" : "bg-emerald-700 text-white")}>
          {toast.msg}
        </div>
      )}
    </div>
  );
}

/* ----------------------------------------------------------------------- shared bits */
function Field({ label, children }) {
  return <label className="block"><span className="block text-sm font-semibold mb-1">{label}</span>{children}</label>;
}
function Tag({ tag, t }) {
  return <span className={"text-xs font-bold px-2 py-1 rounded " + TAG_STYLE[tag]}>{t[tag]}</span>;
}
function Quality({ score, t }) {
  if (score == null) return null;
  return <span className="text-xs font-bold px-2 py-1 rounded bg-slate-900 text-amber-300">✓ {t.quality}: {score}/100</span>;
}

/* ----------------------------------------------------------------------- auth */
function Auth({ t, api, notify, onAuth, onClose }) {
  const [mode, setMode] = useState("login");
  const [f, setF] = useState({ full_name: "", phone_number: "", email: "", password: "", telegram_id: "" });
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const submit = async (e) => {
    e.preventDefault(); setBusy(true);
    try {
      const r = mode === "login"
        ? await api("/auth/login", { method: "POST", json: { identifier: f.phone_number || f.email, password: f.password } })
        : await api("/auth/register", { method: "POST", json: { full_name: f.full_name, phone_number: f.phone_number, password: f.password, email: f.email || null, telegram_id: f.telegram_id ? Number(f.telegram_id) : null } });
      onAuth(r);
    } catch (err) { notify(err.message, true); } finally { setBusy(false); }
  };
  return (
    <div className="fixed inset-0 bg-slate-900/70 flex items-center justify-center p-4 z-40" role="dialog" aria-modal="true">
      <form onSubmit={submit} className="bg-white rounded-lg border-2 border-slate-900 p-6 w-full max-w-sm space-y-3">
        <div className="flex gap-2">
          {["login", "register"].map((m) => (
            <button type="button" key={m} onClick={() => setMode(m)} className={"flex-1 py-2 rounded-md font-bold border-2 border-slate-900 " + (mode === m ? "bg-slate-900 text-white" : "bg-white")}>
              {m === "login" ? t.login : t.register}
            </button>
          ))}
        </div>
        {mode === "register" && <Field label={t.fullName}><input className={inputCls} value={f.full_name} onChange={set("full_name")} required minLength={2} /></Field>}
        <Field label={t.phone}><input className={inputCls} value={f.phone_number} onChange={set("phone_number")} placeholder="09XXXXXXXX" required /></Field>
        {mode === "register" && <>
          <Field label={t.email}><input type="email" className={inputCls} value={f.email} onChange={set("email")} /></Field>
          <Field label={t.tgId}><input inputMode="numeric" className={inputCls} value={f.telegram_id} onChange={set("telegram_id")} /></Field>
        </>}
        <Field label={t.password}><input type="password" className={inputCls} value={f.password} onChange={set("password")} required minLength={8} /></Field>
        <div className="flex gap-2 pt-1">
          <button disabled={busy} className={btnPrimary + " flex-1"}>{mode === "login" ? t.login : t.register}</button>
          <button type="button" onClick={onClose} className={btnGhost}>{t.cancel}</button>
        </div>
      </form>
    </div>
  );
}

/* ----------------------------------------------------------------------- marketplace */
function Market({ t, lang, api, onOpen, notify }) {
  const [platform, setPlatform] = useState("");
  const [q, setQ] = useState("");
  const [sort, setSort] = useState("new");
  const [rows, setRows] = useState(null);
  useEffect(() => {
    const p = new URLSearchParams({ sort });
    if (platform) p.set("platform", platform);
    if (q) p.set("q", q);
    const h = setTimeout(() => api("/listings?" + p).then(setRows).catch((e) => { setRows([]); notify(e.message, true); }), 250);
    return () => clearTimeout(h);
  }, [platform, q, sort, api]);

  return (
    <div>
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 mb-4" role="tablist">
        {[["", t.all], ...PLATFORMS.map((p) => [p, PLABEL[p]])].map(([k, label]) => (
          <button key={k} role="tab" aria-selected={platform === k} onClick={() => setPlatform(k)}
            className={"py-3 px-2 rounded-md text-sm font-bold border-2 border-slate-900 " + (platform === k ? "bg-amber-400" : "bg-white hover:bg-slate-100")}>
            {label}
          </button>
        ))}
      </div>
      <div className="flex gap-2 mb-5">
        <input className={inputCls} placeholder="🔍" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search" />
        <select className={inputCls + " max-w-xs"} value={sort} onChange={(e) => setSort(e.target.value)} aria-label="Sort">
          <option value="new">{lang === "am" ? "አዲስ" : "Newest"}</option>
          <option value="price_asc">{lang === "am" ? "ዋጋ ↑" : "Price low-high"}</option>
          <option value="price_desc">{lang === "am" ? "ዋጋ ↓" : "Price high-low"}</option>
          <option value="followers">{t.followers}</option>
        </select>
      </div>
      {rows === null ? <p>…</p> : rows.length === 0 ? <p className="py-12 text-center text-slate-600">{t.empty}</p> : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {rows.map((l) => (
            <button key={l.id} onClick={() => onOpen(l.id)} className="text-left bg-white rounded-lg border-2 border-slate-900 p-4 hover:bg-amber-50 focus:outline-none focus:ring-2 focus:ring-amber-400">
              <div className="flex justify-between items-start gap-2 mb-2">
                <span className="text-xs font-bold bg-slate-900 text-white px-2 py-1 rounded">{PLABEL[l.platform_type]}</span>
                <Tag tag={l.valuation_tag} t={t} />
              </div>
              <h3 className="font-extrabold text-lg leading-snug mb-1">{l.account_title}</h3>
              <p className="text-sm text-slate-600 mb-3">{l.category}</p>
              <dl className="grid grid-cols-2 gap-y-1 text-sm">
                <dt className="text-slate-600">{t.followers}</dt><dd className="font-bold text-right">{fmtK(l.followers_subscribers_count)}</dd>
                <dt className="text-slate-600">{t.revenue}</dt><dd className="font-bold text-right">{etb(l.monthly_revenue_etb)}</dd>
              </dl>
              <p className="mt-3 text-xl font-extrabold">{etb(l.asking_price_etb)}</p>
              <div className="mt-2"><Quality score={l.quality_score} t={t} /></div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function Detail({ id, t, lang, api, me, onBack, needLogin, notify, onDeal }) {
  const [l, setL] = useState(null);
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [days, setDays] = useState("");
  useEffect(() => { api("/listings/" + id).then((d) => { setL(d); setAmount(String(d.asking_price_etb)); }).catch((e) => notify(e.message, true)); }, [id]);
  if (!l) return <p>…</p>;
  const amt = Number(amount) || 0;
  const fee = Math.round(amt * 2) / 100;
  const start = async (e) => {
    e.preventDefault();
    try {
      await api("/escrow", { method: "POST", json: { listing_id: l.id, agreed_amount_etb: amt, cooldown_days: days ? Number(days) : null } });
      notify("✓"); onDeal();
    } catch (err) { notify(err.message, true); }
  };
  return (
    <div>
      <button onClick={onBack} className="underline font-semibold mb-4">← {t.back}</button>
      <div className="grid md:grid-cols-5 gap-6">
        <div className="md:col-span-3 space-y-4">
          <div className="flex flex-wrap gap-2 items-center">
            <span className="text-xs font-bold bg-slate-900 text-white px-2 py-1 rounded">{PLABEL[l.platform_type]}</span>
            <Tag tag={l.valuation_tag} t={t} /><Quality score={l.quality_score} t={t} />
            {l.status === "Sold" && <span className="text-xs font-bold px-2 py-1 rounded bg-slate-300">{t.sold}</span>}
          </div>
          <h1 className="text-3xl font-extrabold">{l.account_title}</h1>
          <dl className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[[t.followers, fmtK(l.followers_subscribers_count)], [t.engagement, l.engagement_rate != null ? l.engagement_rate + "%" : "-"], [t.category, l.category], [t.revenue, etb(l.monthly_revenue_etb)]].map(([k, v]) => (
              <div key={k} className="bg-white border-2 border-slate-900 rounded-md p-3"><dt className="text-xs text-slate-600">{k}</dt><dd className="font-extrabold">{v}</dd></div>
            ))}
          </dl>
          <p className="whitespace-pre-wrap">{l.description}</p>
          {l.proof_image_url && (
            <figure>
              <figcaption className="text-sm font-semibold mb-1">{t.proof}</figcaption>
              <img src={API + l.proof_image_url} alt={t.proof} className="w-full rounded-md border-2 border-slate-900" />
            </figure>
          )}
        </div>
        <aside className="md:col-span-2">
          <div className="bg-white border-2 border-slate-900 rounded-lg p-4 sticky top-4">
            <p className="text-sm text-slate-600">{t.price}</p>
            <p className="text-3xl font-extrabold mb-3">{etb(l.asking_price_etb)}</p>
            {l.status === "Active" && !open && <button className={btnPrimary + " w-full"} onClick={() => (me ? setOpen(true) : needLogin())}>{t.startEscrow}</button>}
            {open && (
              <form onSubmit={start} className="space-y-3">
                <Field label={t.agreed}><input type="number" min="1" step="0.01" className={inputCls} value={amount} onChange={(e) => setAmount(e.target.value)} required /></Field>
                <Field label={t.cooldown}>
                  <select className={inputCls} value={days} onChange={(e) => setDays(e.target.value)}>
                    <option value="">{lang === "am" ? "ነባሪ" : "Default"}</option>
                    {[3, 4, 5, 6, 7].map((d) => <option key={d} value={d}>{d}</option>)}
                  </select>
                </Field>
                <div className="text-sm bg-slate-100 rounded-md p-3 space-y-1">
                  <div className="flex justify-between"><span>{t.fee}</span><b>{etb(fee)}</b></div>
                  <div className="flex justify-between"><span>{t.payout}</span><b>{etb(amt - fee)}</b></div>
                </div>
                <p className="text-xs text-slate-600">{t.offPlatform}</p>
                <div className="flex gap-2"><button className={btnPrimary + " flex-1"}>{t.startEscrow}</button><button type="button" onClick={() => setOpen(false)} className={btnGhost}>{t.cancel}</button></div>
              </form>
            )}
          </div>
        </aside>
      </div>
    </div>
  );
}

/* ----------------------------------------------------------------------- create listing */
function Sell({ t, api, notify, onDone }) {
  const blank = { platform_type: "Telegram", account_title: "", category: "", followers_subscribers_count: "", monthly_revenue_etb: "0", asking_price_etb: "", description: "", handle: "" };
  const [f, setF] = useState(blank);
  const [file, setFile] = useState(null);
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const submit = async (e) => {
    e.preventDefault();
    if (!file) return notify(t.proof, true);
    setBusy(true);
    const fd = new FormData();
    Object.entries(f).forEach(([k, v]) => v !== "" && fd.append(k, v));
    fd.append("proof_image", file);
    try { await api("/listings", { method: "POST", form: fd }); notify(t.saved); onDone(); }
    catch (err) { notify(err.message, true); } finally { setBusy(false); }
  };
  return (
    <form onSubmit={submit} className="max-w-2xl bg-white border-2 border-slate-900 rounded-lg p-6 space-y-4">
      <h1 className="text-2xl font-extrabold">{t.sell}</h1>
      <p className="text-sm text-slate-600">{t.sellerNote}</p>
      <Field label="Platform"><select className={inputCls} value={f.platform_type} onChange={set("platform_type")}>{PLATFORMS.map((p) => <option key={p} value={p}>{PLABEL[p]}</option>)}</select></Field>
      <Field label={t.title}><input className={inputCls} value={f.account_title} onChange={set("account_title")} required minLength={3} /></Field>
      <div className="grid sm:grid-cols-2 gap-4">
        <Field label={t.category}><input className={inputCls} value={f.category} onChange={set("category")} required /></Field>
        <Field label={t.followers}><input type="number" min="0" className={inputCls} value={f.followers_subscribers_count} onChange={set("followers_subscribers_count")} required /></Field>
        <Field label={t.revenue + " (ETB)"}><input type="number" min="0" className={inputCls} value={f.monthly_revenue_etb} onChange={set("monthly_revenue_etb")} /></Field>
        <Field label={t.price + " (ETB)"}><input type="number" min="1" className={inputCls} value={f.asking_price_etb} onChange={set("asking_price_etb")} required /></Field>
      </div>
      <Field label={t.handle}><input className={inputCls} value={f.handle} onChange={set("handle")} /></Field>
      <Field label={t.description}><textarea rows={4} className={inputCls} value={f.description} onChange={set("description")} /></Field>
      <Field label={t.proof}><input type="file" accept="image/png,image/jpeg,image/webp" onChange={(e) => setFile(e.target.files[0] || null)} className="block w-full text-sm" required /></Field>
      <button disabled={busy} className={btnPrimary}>{t.submit}</button>
    </form>
  );
}

/* ----------------------------------------------------------------------- deals + chat */
function timeLeft(iso) {
  const ms = new Date(iso + "Z") - Date.now();
  if (ms <= 0) return "0h";
  const d = Math.floor(ms / 864e5), h = Math.floor((ms % 864e5) / 36e5);
  return d ? `${d}d ${h}h` : `${h}h`;
}

function Deals({ t, lang, api, me, notify }) {
  const [rows, setRows] = useState(null);
  const [chat, setChat] = useState(null);
  const load = useCallback(() => api("/escrow").then(setRows).catch((e) => { setRows([]); notify(e.message, true); }), [api]);
  useEffect(() => { load(); }, [load]);
  const act = async (id, action, json) => {
    try { await api(`/escrow/${id}/${action}`, { method: "POST", json }); load(); }
    catch (e) { notify(e.message, true); }
  };
  const dispute = (id) => { const reason = window.prompt(t.reason); if (reason) act(id, "dispute", { reason }); };
  if (rows === null) return <p>…</p>;
  if (!rows.length) return <p className="py-12 text-center text-slate-600">{t.noDeals}</p>;
  return (
    <div className="space-y-4">
      {rows.map((d) => {
        const buyer = d.buyer_id === me.id, seller = d.seller_id === me.id;
        const live = ["Secured_in_Escrow", "Credentials_Transferred", "Buyer_Verification_Period"].includes(d.status);
        return (
          <div key={d.id} className="bg-white border-2 border-slate-900 rounded-lg p-4">
            <div className="flex flex-wrap justify-between gap-2">
              <h3 className="font-extrabold text-lg">#{d.id} · {d.listing_title}</h3>
              <span className="text-sm font-bold bg-amber-300 px-2 py-1 rounded">{STATUS[lang][d.status]}</span>
            </div>
            <p className="text-sm text-slate-600 mb-2">{buyer ? (lang === "am" ? "ገዢ" : "Buyer") : (lang === "am" ? "ሻጭ" : "Seller")} · {etb(d.agreed_amount_etb)} · {t.fee}: {etb(d.commission_fee_etb)} · {t.payout}: {etb(d.seller_payout_etb)}</p>
            {d.status === "Pending_Deposit" && buyer && <p className="text-sm bg-slate-100 rounded p-2 mb-2">{t.payRef}: <b>{d.payment_reference}</b></p>}
            {d.status === "Buyer_Verification_Period" && <p className="text-sm font-semibold mb-2">⏳ {timeLeft(d.cooldown_ends_at)} {t.holdLeft}</p>}
            {d.dispute_reason && <p className="text-sm text-rose-800 mb-2">⚠ {d.dispute_reason}</p>}
            {d.resolution_note && <p className="text-sm mb-2">✔ {d.resolution_note}</p>}
            <div className="flex flex-wrap gap-2">
              {me.is_admin && d.status === "Pending_Deposit" && <button className={btnPrimary} onClick={() => act(d.id, "confirm-deposit")}>{t.confirmDeposit}</button>}
              {seller && d.status === "Secured_in_Escrow" && <button className={btnPrimary} onClick={() => act(d.id, "credentials-transferred")}>{t.transferred}</button>}
              {buyer && d.status === "Credentials_Transferred" && <button className={btnPrimary} onClick={() => act(d.id, "confirm-access")}>{t.confirmAccess}</button>}
              {live && <button className={btnGhost} onClick={() => dispute(d.id)}>{t.dispute}</button>}
              <button className={btnGhost} onClick={() => setChat(chat === d.id ? null : d.id)}>{t.chat}</button>
            </div>
            {chat === d.id && <Chat id={d.id} me={me} t={t} api={api} notify={notify} />}
          </div>
        );
      })}
    </div>
  );
}

function Chat({ id, me, t, api, notify }) {
  const [msgs, setMsgs] = useState([]);
  const [body, setBody] = useState("");
  const load = useCallback(() => api(`/escrow/${id}/messages`).then(setMsgs).catch(() => {}), [api, id]);
  useEffect(() => { load(); const h = setInterval(load, 8000); return () => clearInterval(h); }, [load]);
  const send = async (e) => {
    e.preventDefault();
    try {
      const r = await api(`/escrow/${id}/messages`, { method: "POST", json: { body } });
      if (r.warning) notify(r.warning, true);
      setBody(""); load();
    } catch (err) { notify(err.message, true); }
  };
  return (
    <div className="mt-3 border-t-2 border-slate-200 pt-3">
      <div className="max-h-56 overflow-y-auto space-y-1 mb-2">
        {msgs.map((m) => (
          <div key={m.id} className={"text-sm px-3 py-1.5 rounded-md max-w-md " + (m.sender_id === me.id ? "ml-auto bg-slate-900 text-white" : "bg-slate-100") + (m.flagged ? " ring-2 ring-rose-500" : "")}>{m.body}</div>
        ))}
      </div>
      <form onSubmit={send} className="flex gap-2">
        <input className={inputCls} value={body} onChange={(e) => setBody(e.target.value)} required maxLength={2000} />
        <button className={btnPrimary}>{t.send}</button>
      </form>
      <p className="text-xs text-slate-600 mt-1">{t.offPlatform}</p>
    </div>
  );
}

/* ----------------------------------------------------------------------- sold archive */
function Archive({ t, api, notify }) {
  const [rows, setRows] = useState(null);
  useEffect(() => { api("/archive").then(setRows).catch((e) => { setRows([]); notify(e.message, true); }); }, [api]);
  if (rows === null) return <p>…</p>;
  if (!rows.length) return <p className="py-12 text-center text-slate-600">{t.noArchive}</p>;
  return (
    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {rows.map((r, i) => (
        <div key={i} className="bg-white border-2 border-slate-900 rounded-lg p-4">
          <div className="flex justify-between mb-2"><span className="text-xs font-bold bg-slate-900 text-white px-2 py-1 rounded">{PLABEL[r.platform_type]}</span><span className="text-xs text-slate-600">{r.completed_on}</span></div>
          <p className="font-extrabold tracking-widest">{r.masked_title}</p>
          <p className="text-sm text-slate-600">{r.category} · {r.followers_bucket}</p>
          <p className="mt-2 text-lg font-extrabold">{etb(r.sold_price_etb)}</p>
        </div>
      ))}
    </div>
  );
}

/* ----------------------------------------------------------------------- admin */
function Admin({ t, lang, api, notify }) {
  const [pending, setPending] = useState([]);
  const [disputes, setDisputes] = useState([]);
  const [deposits, setDeposits] = useState([]);
  const load = useCallback(() => {
    api("/admin/deposits").then(setDeposits).catch((e) => notify(e.message, true));
    api("/admin/listings").then(setPending).catch((e) => notify(e.message, true));
    api("/admin/disputes").then(setDisputes).catch((e) => notify(e.message, true));
  }, [api]);
  useEffect(() => { load(); }, [load]);
  const listingAct = async (id, a) => { try { await api(`/admin/listings/${id}/${a}`, { method: "POST" }); load(); } catch (e) { notify(e.message, true); } };
  const confirmDeposit = async (id) => { try { await api(`/escrow/${id}/confirm-deposit`, { method: "POST" }); load(); } catch (e) { notify(e.message, true); } };
  const resolve = async (id, outcome) => {
    const note = window.prompt(t.note);
    if (!note) return;
    try { await api(`/admin/escrow/${id}/resolve`, { method: "POST", json: { outcome, note } }); load(); } catch (e) { notify(e.message, true); }
  };
  return (
    <div className="grid lg:grid-cols-2 gap-6">
      <section className="lg:col-span-2">
        <h2 className="text-xl font-extrabold mb-3">{t.confirmDeposit} ({deposits.length})</h2>
        <div className="grid sm:grid-cols-2 gap-3">
          {deposits.map((d) => (
            <div key={d.id} className="bg-white border-2 border-slate-900 rounded-lg p-3">
              <p className="font-bold">#{d.id} · {d.listing_title} · {etb(d.agreed_amount_etb)}</p>
              <p className="text-sm text-slate-600">{d.payment_reference}</p>
              <button className={btnPrimary + " mt-2"} onClick={() => confirmDeposit(d.id)}>{t.confirmDeposit}</button>
            </div>
          ))}
        </div>
      </section>
      <section>
        <h2 className="text-xl font-extrabold mb-3">{t.review} ({pending.length})</h2>
        <div className="space-y-3">
          {pending.map((l) => (
            <div key={l.id} className="bg-white border-2 border-slate-900 rounded-lg p-3">
              <p className="font-bold">{l.account_title} <span className="text-sm font-normal text-slate-600">· {PLABEL[l.platform_type]} · {fmtK(l.followers_subscribers_count)} · {etb(l.asking_price_etb)}</span></p>
              {l.handle && <p className="text-sm text-slate-600">{l.handle}</p>}
              {l.proof_image_url && <a className="text-sm underline" href={API + l.proof_image_url} target="_blank" rel="noreferrer">{t.proof}</a>}
              <div className="flex gap-2 mt-2"><button className={btnPrimary} onClick={() => listingAct(l.id, "approve")}>{t.approve}</button><button className={btnGhost} onClick={() => listingAct(l.id, "suspend")}>{t.suspend}</button></div>
            </div>
          ))}
        </div>
      </section>
      <section>
        <h2 className="text-xl font-extrabold mb-3">{t.disputes} ({disputes.length})</h2>
        <div className="space-y-3">
          {disputes.map((d) => (
            <div key={d.id} className="bg-white border-2 border-rose-700 rounded-lg p-3">
              <p className="font-bold">#{d.id} · {d.listing_title} · {etb(d.agreed_amount_etb)}</p>
              <p className="text-sm text-rose-800">{d.dispute_reason}</p>
              <div className="flex gap-2 mt-2"><button className={btnPrimary} onClick={() => resolve(d.id, "release_to_seller")}>{t.release}</button><button className={btnGhost} onClick={() => resolve(d.id, "refund_buyer")}>{t.refund}</button></div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
